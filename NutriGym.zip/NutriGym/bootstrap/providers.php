<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\GeminiServiceProvider::class,
    App\Providers\VoltServiceProvider::class,
];
